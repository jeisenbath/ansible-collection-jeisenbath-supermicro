===================================
Jeisenbath.Supermicro Release Notes
===================================

.. contents:: Topics


v1.1.0
======

Release Summary
---------------

Released 2025-07-21

Major Changes
-------------

- create role ssm_install

v1.0.0
======

Release Summary
---------------

Released 2025-07-11

Major Changes
-------------

- accounts role added
- bios role added
- interfaces role added
- managers role added
- network_protocols role added
